import { cn } from '@/lib/utils';

export function Logo({ className, conTexto = true }: { className?: string; conTexto?: boolean }) {
  return (
    <span className={cn('flex items-center gap-2 font-semibold', className)}>
      <svg viewBox="0 0 48 48" className="size-8 shrink-0" aria-hidden="true">
        <circle cx="24" cy="24" r="24" fill="#16a34a" />
        <circle cx="19" cy="19" r="7" fill="#fcd34d" />
        <path d="M14 33a7 7 0 0 1 1.5-13.8A9 9 0 0 1 33 21a6 6 0 0 1 1 12z" fill="#fff" />
        <path d="M22 37c0-4 3-7 7-8-1 4-3 7-7 8z" fill="#15803d" />
      </svg>
      {conTexto && (
        <span className="text-lg tracking-tight">
          IAGRO <span className="font-normal text-muted-foreground">Panel</span>
        </span>
      )}
    </span>
  );
}
